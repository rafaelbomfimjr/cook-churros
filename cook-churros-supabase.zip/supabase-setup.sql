-- Execute esse SQL no Supabase → SQL Editor → New Query
-- Cria a tabela que armazena todos os dados do app

create table if not exists dados (
  chave text primary key,
  valor jsonb not null,
  atualizado_em timestamptz default now()
);

-- Permite leitura e escrita sem autenticação (app público)
alter table dados enable row level security;

create policy "Leitura pública" on dados
  for select using (true);

create policy "Escrita pública" on dados
  for insert with check (true);

create policy "Atualização pública" on dados
  for update using (true);
